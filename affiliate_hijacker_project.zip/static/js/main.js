/**
 * Affiliate Hijacker - Main JavaScript
 * Handles global UI functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Handle URL form validation
    const urlForms = document.querySelectorAll('form[action="/analyze"]');
    urlForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            const urlInput = form.querySelector('input[name="url"]');
            if (urlInput && !validateUrl(urlInput)) {
                event.preventDefault();
                showMessage('danger', 'Please enter a valid URL including http:// or https://');
            }
        });
    });
    
    // Auto-hide flash messages after 5 seconds
    setTimeout(function() {
        const flashMessages = document.querySelectorAll('.alert');
        flashMessages.forEach(message => {
            const alert = new bootstrap.Alert(message);
            alert.close();
        });
    }, 5000);
});

/**
 * Validate a URL input
 * @param {HTMLInputElement} input - The input element to validate
 * @returns {boolean} - True if valid, false otherwise
 */
function validateUrl(input) {
    try {
        const url = new URL(input.value);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

/**
 * Submit a form via AJAX
 * @param {HTMLFormElement} form - The form to submit
 */
function submitFormAjax(form) {
    const formData = new FormData(form);
    const url = form.getAttribute('action');
    const method = form.getAttribute('method') || 'POST';
    
    fetch(url, {
        method: method,
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.redirect) {
                window.location.href = data.redirect;
            } else {
                showMessage('success', data.message || 'Action completed successfully');
            }
        } else {
            showMessage('danger', data.error || 'An error occurred');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessage('danger', 'An error occurred. Please try again.');
    });
}

/**
 * Display a message to the user
 * @param {string} type - The message type (success, danger, warning, info)
 * @param {string} message - The message text
 */
function showMessage(type, message) {
    // Check if alert container exists, create if not
    let alertContainer = document.querySelector('.alert-container');
    if (!alertContainer) {
        alertContainer = document.createElement('div');
        alertContainer.classList.add('alert-container');
        document.body.appendChild(alertContainer);
    }
    
    // Create alert
    const alert = document.createElement('div');
    alert.classList.add('alert', `alert-${type}`, 'alert-dismissible', 'fade', 'show');
    alert.role = 'alert';
    
    // Add message and close button
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add to container
    alertContainer.appendChild(alert);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => {
            alert.remove();
        }, 300);
    }, 5000);
}

/**
 * Handle validation errors for a form
 * @param {HTMLFormElement} form - The form with errors
 * @param {Object} errors - Object containing field names and error messages
 */
function handleValidationErrors(form, errors) {
    // Reset previous error messages
    form.querySelectorAll('.is-invalid').forEach(field => {
        field.classList.remove('is-invalid');
    });
    form.querySelectorAll('.invalid-feedback').forEach(message => {
        message.remove();
    });
    
    // Add new error messages
    for (const field in errors) {
        const inputField = form.querySelector(`[name="${field}"]`);
        if (inputField) {
            inputField.classList.add('is-invalid');
            
            const feedbackDiv = document.createElement('div');
            feedbackDiv.classList.add('invalid-feedback');
            feedbackDiv.textContent = errors[field];
            
            inputField.parentNode.appendChild(feedbackDiv);
        }
    }
}