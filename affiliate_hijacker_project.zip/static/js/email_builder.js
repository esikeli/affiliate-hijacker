/**
 * Affiliate Hijacker - Email Builder JavaScript
 * Handles email sequence generation and preview
 */

document.addEventListener('DOMContentLoaded', function() {
    initEmailBuilder();
});

/**
 * Initialize the email builder functionality
 */
function initEmailBuilder() {
    setupSequenceTypeSelector();
    setupEmailRangeSlider();
    setupEmailFormSubmission();
}

/**
 * Set up the sequence type selector cards
 */
function setupSequenceTypeSelector() {
    // Get all sequence type radio buttons
    const sequenceTypes = document.querySelectorAll('input[name="sequence_type"]');
    const emailStyles = document.querySelectorAll('input[name="email_style"]');
    
    // Add event listeners to update the email preview when the type changes
    sequenceTypes.forEach(radio => {
        radio.addEventListener('change', function() {
            updateSequenceDescription(this.value);
        });
    });
    
    // Initialize with the default selected value
    const defaultType = document.querySelector('input[name="sequence_type"]:checked');
    if (defaultType) {
        updateSequenceDescription(defaultType.value);
    }
    
    // Add event listeners for email styles to update preview
    emailStyles.forEach(radio => {
        radio.addEventListener('change', function() {
            updateStyleDescription(this.value);
        });
    });
    
    // Initialize with the default selected style
    const defaultStyle = document.querySelector('input[name="email_style"]:checked');
    if (defaultStyle) {
        updateStyleDescription(defaultStyle.value);
    }
}

/**
 * Set up the email range slider
 */
function setupEmailRangeSlider() {
    const rangeSlider = document.getElementById('num_emails');
    if (rangeSlider) {
        rangeSlider.addEventListener('input', function() {
            updateEmailCount(this.value);
        });
        
        // Initialize with default value
        updateEmailCount(rangeSlider.value);
    }
}

/**
 * Set up the email form submission
 */
function setupEmailFormSubmission() {
    const emailForm = document.querySelector('form[action*="generate_emails"]');
    if (emailForm) {
        emailForm.addEventListener('submit', function(event) {
            // Show loading state
            const submitButton = this.querySelector('button[type="submit"]');
            if (submitButton) {
                const originalText = submitButton.textContent;
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...';
                
                // We'll let the form submit normally, but if we wanted to use AJAX:
                // event.preventDefault();
                // submitFormAjax(this);
                
                // Reset button after a timeout if we're not redirecting
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.textContent = originalText;
                }, 10000); // Reset after 10 seconds if no redirect happens
            }
        });
    }
}

/**
 * Update the sequence description based on selected type
 */
function updateSequenceDescription(sequenceType) {
    const descriptionEl = document.getElementById('sequence-description');
    if (!descriptionEl) return;
    
    let description = '';
    switch(sequenceType) {
        case 'sales':
            description = 'A sales sequence focuses on converting leads into customers, highlighting benefits and creating urgency.';
            break;
        case 'nurture':
            description = 'A nurture sequence builds trust over time by providing valuable content and establishing authority.';
            break;
        case 'onboarding':
            description = 'An onboarding sequence welcomes new customers and helps them get the most value from their purchase.';
            break;
        case 'abandoned cart':
            description = 'An abandoned cart sequence reminds potential customers about products they were interested in but didn\'t purchase.';
            break;
        default:
            description = 'Select a sequence type to see a description.';
    }
    
    descriptionEl.textContent = description;
}

/**
 * Update the style description based on selected style
 */
function updateStyleDescription(emailStyle) {
    const descriptionEl = document.getElementById('style-description');
    if (!descriptionEl) return;
    
    let description = '';
    switch(emailStyle) {
        case 'conversational':
            description = 'Friendly and casual tone, feels like an email from a friend or trusted advisor.';
            break;
        case 'formal':
            description = 'Professional and authoritative, ideal for B2B or high-ticket products and services.';
            break;
        case 'story-based':
            description = 'Uses narratives and personal stories to connect with readers on an emotional level.';
            break;
        case 'direct':
            description = 'Straightforward and concise, gets to the point quickly without unnecessary details.';
            break;
        default:
            description = 'Select an email style to see a description.';
    }
    
    descriptionEl.textContent = description;
}

/**
 * Update the email count display and add timing information
 */
function updateEmailCount(count) {
    const countDisplay = document.getElementById('emails_value');
    if (countDisplay) {
        countDisplay.textContent = count;
    }
    
    // Update email timing information
    updateEmailTiming(parseInt(count));
}

/**
 * Update the email timing information
 */
function updateEmailTiming(emailCount) {
    const timingEl = document.getElementById('email-timing');
    if (!timingEl) return;
    
    // Create a rough schedule based on count
    let timing = '<strong>Approximate schedule:</strong><br>';
    
    // Calculate days between emails (more emails = shorter intervals)
    let interval = emailCount <= 10 ? 2 : 1;
    
    for (let i = 1; i <= Math.min(emailCount, 5); i++) {
        const day = i === 1 ? 'Day 1 (Immediately)' : `Day ${(i-1) * interval + 1}`;
        timing += `Email ${i}: ${day}<br>`;
    }
    
    if (emailCount > 5) {
        timing += `... plus ${emailCount - 5} more emails sent over ${(emailCount - 5) * interval} days`;
    }
    
    timingEl.innerHTML = timing;
}

/**
 * Generate a preview of email templates
 * This would typically be called after receiving data from the server,
 * but we can include a placeholder version for immediate visual feedback
 * 
 * @param {Array} emailData - Array of email templates
 */
function generateEmailPreview(emailData) {
    const previewContainer = document.getElementById('email-previews');
    if (!previewContainer) return;
    
    // Clear existing previews
    previewContainer.innerHTML = '';
    
    if (!emailData || emailData.length === 0) {
        createMockEmailPreview();
        return;
    }
    
    // Create preview for each email
    emailData.forEach((email, index) => {
        const emailDiv = document.createElement('div');
        emailDiv.className = 'email-preview mb-4';
        
        const subject = document.createElement('div');
        subject.className = 'subject';
        subject.textContent = email.subject || `Email ${index + 1} Subject`;
        
        const body = document.createElement('div');
        body.className = 'body';
        body.textContent = email.body || 'Email body content goes here...';
        
        emailDiv.appendChild(subject);
        emailDiv.appendChild(body);
        previewContainer.appendChild(emailDiv);
    });
}

/**
 * Create a mock email preview for testing purposes
 */
function createMockEmailPreview() {
    const previewContainer = document.getElementById('email-previews');
    if (!previewContainer) return;
    
    const mockEmails = [
        {
            subject: 'Welcome to Our Community!',
            body: 'Thank you for joining us! We're excited to have you on board. Here's what you can expect in the coming days...'
        },
        {
            subject: 'Discover the Benefits of [Product]',
            body: 'I wanted to tell you about some amazing benefits you'll experience with our product...'
        },
        {
            subject: 'Limited Time Offer Inside',
            body: 'As a valued subscriber, we're extending a special limited-time offer just for you...'
        }
    ];
    
    generateEmailPreview(mockEmails);
}