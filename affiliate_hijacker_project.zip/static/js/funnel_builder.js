/**
 * Affiliate Hijacker - Funnel Builder JavaScript
 * Handles funnel visualization and customization
 */

document.addEventListener('DOMContentLoaded', function() {
    initFunnelBuilder();
});

/**
 * Initialize the funnel builder functionality
 */
function initFunnelBuilder() {
    // Funnel customization form listeners
    setupFormListeners();
    
    // Draw funnel flow diagram if element exists
    if (document.getElementById('funnel-diagram')) {
        drawFunnelFlowDiagram();
    }
}

/**
 * Draw the funnel flow diagram using SVG
 */
function drawFunnelFlowDiagram() {
    const container = document.getElementById('funnel-diagram');
    const width = container.offsetWidth;
    const height = 400;
    
    // Create SVG
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("width", width);
    svg.setAttribute("height", height);
    container.appendChild(svg);
    
    // Box dimensions
    const boxWidth = 180;
    const boxHeight = 70;
    const vertGap = 50;
    
    // Draw main page box
    createBox(svg, width/2 - boxWidth/2, 20, boxWidth, boxHeight, "#0d6efd", "Main Sales Page", "Starting point");
    
    // Create arrows
    createArrow(svg, width/2, 90, width/2, 120, "#0d6efd");
    
    // Upsell 1
    createBox(svg, width/2 - boxWidth/2, 120, boxWidth, boxHeight, "#28a745", "Upsell 1", "Higher value offer");
    
    // Create arrows from Upsell 1
    createArrow(svg, width/2, 190, width/2, 220, "#28a745"); // Accept arrow
    createArrow(svg, width/2 - boxWidth/2, 155, width/4, 220, "#dc3545", true); // Decline arrow
    
    // Downsell 1
    createBox(svg, width/4 - boxWidth/2, 220, boxWidth, boxHeight, "#dc3545", "Downsell 1", "Alternative offer");
    
    // Upsell 2
    createBox(svg, width/2 - boxWidth/2, 220, boxWidth, boxHeight, "#28a745", "Upsell 2", "Second upsell");
    
    // Create arrows
    createArrow(svg, width/4, 290, width/2, 340, "#dc3545"); // Downsell to Thank You
    createArrow(svg, width/2, 290, width/2, 340, "#28a745"); // Upsell to Thank You
    
    // Thank You page
    createBox(svg, width/2 - boxWidth/2, 340, boxWidth, boxHeight, "#17a2b8", "Thank You Page", "Confirmation page");
}

/**
 * Create a box in the SVG for a funnel page
 */
function createBox(container, x, y, width, height, color, title, subtitle) {
    // Create group
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
    
    // Create rectangle
    const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    rect.setAttribute("x", x);
    rect.setAttribute("y", y);
    rect.setAttribute("width", width);
    rect.setAttribute("height", height);
    rect.setAttribute("rx", "5");
    rect.setAttribute("ry", "5");
    rect.setAttribute("fill", color);
    rect.setAttribute("opacity", "0.9");
    g.appendChild(rect);
    
    // Create title text
    const titleText = document.createElementNS("http://www.w3.org/2000/svg", "text");
    titleText.setAttribute("x", x + width/2);
    titleText.setAttribute("y", y + 25);
    titleText.setAttribute("text-anchor", "middle");
    titleText.setAttribute("fill", "white");
    titleText.setAttribute("font-weight", "bold");
    titleText.textContent = title;
    g.appendChild(titleText);
    
    // Create subtitle text
    const subtitleText = document.createElementNS("http://www.w3.org/2000/svg", "text");
    subtitleText.setAttribute("x", x + width/2);
    subtitleText.setAttribute("y", y + 45);
    subtitleText.setAttribute("text-anchor", "middle");
    subtitleText.setAttribute("fill", "white");
    subtitleText.setAttribute("font-size", "12");
    subtitleText.textContent = subtitle;
    g.appendChild(subtitleText);
    
    container.appendChild(g);
    return g;
}

/**
 * Create an arrow connecting two points in the SVG
 */
function createArrow(container, x1, y1, x2, y2, color, dashed = false) {
    // Create line
    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
    line.setAttribute("x1", x1);
    line.setAttribute("y1", y1);
    line.setAttribute("x2", x2);
    line.setAttribute("y2", y2);
    line.setAttribute("stroke", color);
    line.setAttribute("stroke-width", "2");
    
    if (dashed) {
        line.setAttribute("stroke-dasharray", "5,5");
    }
    
    container.appendChild(line);
    
    // Create arrowhead
    const arrowHead = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    
    // Calculate arrow direction
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const size = 8;
    
    // Calculate arrow points
    const point1x = x2 - size * Math.cos(angle - Math.PI/6);
    const point1y = y2 - size * Math.sin(angle - Math.PI/6);
    const point2x = x2 - size * Math.cos(angle + Math.PI/6);
    const point2y = y2 - size * Math.sin(angle + Math.PI/6);
    
    arrowHead.setAttribute("points", `${x2},${y2} ${point1x},${point1y} ${point2x},${point2y}`);
    arrowHead.setAttribute("fill", color);
    
    container.appendChild(arrowHead);
    
    return line;
}

/**
 * Set up event listeners for form inputs
 */
function setupFormListeners() {
    // Brand name live update
    const brandInput = document.getElementById('brand_name');
    if (brandInput) {
        brandInput.addEventListener('input', function() {
            updateBrandPreview(this.value);
        });
    }
    
    // Upsell/downsell sliders
    const upsellSlider = document.getElementById('num_upsells');
    const downsellSlider = document.getElementById('num_downsells');
    
    if (upsellSlider && downsellSlider) {
        // Update estimated price points
        upsellSlider.addEventListener('input', function() {
            updatePriceEstimates();
        });
        
        downsellSlider.addEventListener('input', function() {
            updatePriceEstimates();
        });
        
        // Initialize price estimates
        updatePriceEstimates();
    }
}

/**
 * Update the price estimates based on slider values
 */
function updatePriceEstimates() {
    const upsells = parseInt(document.getElementById('num_upsells').value);
    const downsells = parseInt(document.getElementById('num_downsells').value);
    
    const priceEstimateElem = document.getElementById('price-estimate');
    if (priceEstimateElem) {
        // Simple calculation for estimated revenue potential
        const mainPrice = 97; // Example base price
        const avgUpsellValue = 147;
        const avgDownsellValue = 47;
        const conversionRate = 0.3; // 30% conversion assumption
        
        const potential = mainPrice + (upsells * avgUpsellValue + downsells * avgDownsellValue) * conversionRate;
        
        priceEstimateElem.textContent = `$${potential.toFixed(2)}`;
    }
}

/**
 * Update the brand name in preview elements
 */
function updateBrandPreview(brandName) {
    const brandPreviewElems = document.querySelectorAll('.brand-preview');
    brandPreviewElems.forEach(elem => {
        elem.textContent = brandName || 'Your Brand';
    });
}